<?php 
include_once '../../common.php';

/**
 * 订单处理
 */
class Order
{
	function amount()
	{
		# code...
	}
}










 ?>