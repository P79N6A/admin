<?php
namespace JPush;

  const VERSION = '3.5.5';
